package com.example.travel.ui.cities;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.travel.CityAdapter;
import com.example.travel.CityItem;
import com.example.travel.R;

import java.util.ArrayList;

public class CitiesFragment extends Fragment {


    private ArrayList<CityItem> cityItems = new ArrayList<>();

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_cities, container, false);

        RecyclerView recyclerView = root.findViewById(R.id.recycleView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(new CityAdapter(cityItems, getActivity()));
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));


        cityItems.add(new CityItem(R.drawable.sri, "kalutara","Sri lanka","0","Population: 7","abcad dada","Bandaranaike+International+Airport/@6.9726517,79.6403619,9.81z/data=!4m5!3m4!1s0x3ae2efb735f22d5d:0x6ebd702103828b37!8m2!3d7.1801552!4d79.8842521"));
        cityItems.add(new CityItem(R.drawable.sri, "panadura","Sri lanka","1","1000","abcad dada","sssss"));
        cityItems.add(new CityItem(R.drawable.a2, "homagama","Sri lanka","2","27","abcad dada","kdsdsaka"));
        cityItems.add(new CityItem(R.drawable.a1, "pitipana","Sri lanka","3","560","abcad dada","katunsdadsayaka"));
        cityItems.add(new CityItem(R.drawable.sri, "London","England","4","660","abcad dada","London+International+Airport/@43.0285545,-81.152053,17z/data=!3m1!4b1!4m5!3m4!1s0x882e9325e609f739:0x6b27b8df4b0ba78f!8m2!3d43.0285506!4d-81.1498643"));
        cityItems.add(new CityItem(R.drawable.a4, "johannesburg","Africa","5","88880","abcad dada","sdsftunayaka"));
        cityItems.add(new CityItem(R.drawable.sri, "Milan","Italy","6","88880","abcad dada","sdsftunayaka"));
        cityItems.add(new CityItem(R.drawable.a4, "Delhi","India","7","88880","abcad dada","sdsftunayaka"));



        return root;
    }
}
